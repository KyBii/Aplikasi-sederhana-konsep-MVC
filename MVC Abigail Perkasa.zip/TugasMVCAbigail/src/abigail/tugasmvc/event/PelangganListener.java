/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package abigail.tugasmvc.event;

import abigail.tugasmvc.model.PelangganModel;

/**
 *
 * @author Bii
 */
public interface PelangganListener {

    public void onChange(PelangganModel pelanggan);
    
}
